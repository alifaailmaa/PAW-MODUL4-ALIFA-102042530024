<?php

namespace App\Http\Controllers;

use App\Models\Buku;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Menampilkan halaman katalog buku dengan fitur pencarian, filter, sorting, dan paginasi.
     */
    public function index(Request $request)
    {
        // TODO 3: Lengkapi logika index():
        // 1. Buat query pencarian berdasarkan judul, penulis, atau penerbit jika ada input 'search'
        // 2. Tambahkan filter penerbit dan filter ketersediaan stok jika ada input 'penerbit' / 'status'
        // 3. Tambahkan pengurutan data berdasarkan input 'sort' (judul, tahun, stok, default: latest)
        // 4. Lakukan paginasi 8 data dengan withQueryString()
        // 5. Ambil list penerbit unik untuk opsi dropdown filter
        // 6. Return view 'home' dengan data buku dan list penerbit

        $query->when($search, function ($q, $search) {
            return $q->where('judul', 'like', "%{$search}%")
                     ->orWhere('penulis', 'like', "%{$search}%")
                     ->orWhere('penerbit', 'like', "%{$search}%");
        });

        $query->when($penerbit, function ($q, $penerbit) {
            return $q->where('penerbit', $penerbit);
        });

        $query->when($status, function ($q, $status) {
            if ($status === 'tersedia') {
                return $q->where('stok', '>', 0);
            } elseif ($status === 'habis') {
                return $q->where('stok', '=', 0);
            }
        });

        if ($sort === 'judul') {
            $query->orderBy('judul', 'asc');
        } elseif ($sort === 'tahun') {
            $query->orderBy('tahun_terbit', 'desc');
        } elseif ($sort === 'stok') {
            $query->orderBy('stok', 'desc');
        } else {
            // Default sorting: Terbaru (latest)
            $query->latest();
        }

        $buku = $query->paginate(8)->withQueryString();

        $listPenerbit = Buku::select('penerbit')->distinct()->pluck('penerbit');

        return view('home', compact('buku', 'listPenerbit'));



        // $buku = Buku::paginate(8); //liat ini
        // $listPenerbit = collect(); //ini

        
    }

    /**
     * Menampilkan halaman detail informasi sebuah buku untuk publik/mahasiswa.
     */
    public function show(Buku $buku)
    {
        // TODO 3: Kembalikan view 'home_show' membawa data $buku
        return view('home_show', compact('buku'));
    }
}
